/-
================================================================================
  APPENDIX: Lean 4 formalisation

  Accompanying "Connes' Rigidity Conjecture: Disproof of the Counterexamples
  and Proof of the Theorem", J. L. Nielsen, Center for Topological Physics.

  Dependencies: NONE.  This file compiles against a bare Lean 4 toolchain with
  no Mathlib and no other package.  Tested on Lean 4.22.0:

      $ lean ConnesAppendix.lean

  produces no errors and reports the axiom dependencies listed in §C.

  WHAT IS AND IS NOT VERIFIED HERE.

  Part A is unconditional.  Its three theorems depend on no axioms whatsoever
  beyond Lean's own, as §C confirms.

  Part B is a proof skeleton.  It checks that the deductive structure of Part II
  of the paper is valid — that the case elimination leaves only the rigid case,
  and that the rigid case delivers a bijection.  Every analytic input is an
  `axiom`, and §C prints the complete list.  No operator algebra is verified.
  Each axiom corresponds to a cited theorem, named in the comment above it.

  §C exists precisely so that a reader can see the boundary between the two.
================================================================================
-/

universe u v

/-! ============================================================================
    §0.  Preliminaries

    `Function.Injective` and `Function.Surjective` live in Mathlib, not in Lean
    core, so we restate them.  Likewise the group vocabulary: a bare toolchain
    has `Mul`, `One` and `Inv` but no `Group`.
    ========================================================================= -/

namespace Fn

def Injective {α : Sort u} {β : Sort v} (f : α → β) : Prop :=
  ∀ ⦃a b⦄, f a = f b → a = b

def Surjective {α : Sort u} {β : Sort v} (f : α → β) : Prop :=
  ∀ b, ∃ a, f a = b

def Bijective {α : Sort u} {β : Sort v} (f : α → β) : Prop :=
  Injective f ∧ Surjective f

end Fn

class Grp (G : Type u) extends Mul G, One G, Inv G where
  mul_assoc : ∀ a b c : G, a * b * c = a * (b * c)
  one_mul   : ∀ a : G, (1 : G) * a = a
  mul_one   : ∀ a : G, a * (1 : G) = a
  inv_mul   : ∀ a : G, a⁻¹ * a = 1
  mul_inv   : ∀ a : G, a * a⁻¹ = 1

class CommGrp (G : Type u) extends Grp G where
  mul_comm : ∀ a b : G, a * b = b * a

namespace Grp
variable {G : Type u} [Grp G]

theorem mul_left_cancel {a b c : G} (h : a * b = a * c) : b = c := by
  calc b = 1 * b        := (one_mul b).symm
    _ = a⁻¹ * a * b     := by rw [inv_mul]
    _ = a⁻¹ * (a * b)   := mul_assoc _ _ _
    _ = a⁻¹ * (a * c)   := by rw [h]
    _ = a⁻¹ * a * c     := (mul_assoc _ _ _).symm
    _ = 1 * c           := by rw [inv_mul]
    _ = c               := one_mul c

theorem mul_right_cancel {a b c : G} (h : a * c = b * c) : a = b := by
  calc a = a * 1        := (mul_one a).symm
    _ = a * (c * c⁻¹)   := by rw [mul_inv]
    _ = a * c * c⁻¹     := (mul_assoc _ _ _).symm
    _ = b * c * c⁻¹     := by rw [h]
    _ = b * (c * c⁻¹)   := mul_assoc _ _ _
    _ = b * 1           := by rw [mul_inv]
    _ = b               := mul_one b

end Grp

/-- Componentwise group structure on a product. -/
instance instGrpProd {D : Type u} {K : Type v} [Grp D] [Grp K] : Grp (D × K) where
  mul p q := (p.1 * q.1, p.2 * q.2)
  one := (1, 1)
  inv p := (p.1⁻¹, p.2⁻¹)
  mul_assoc a b c := by
    show ((a.1 * b.1) * c.1, (a.2 * b.2) * c.2)
       = (a.1 * (b.1 * c.1), a.2 * (b.2 * c.2))
    rw [Grp.mul_assoc, Grp.mul_assoc]
  one_mul a := by
    show ((1 : D) * a.1, (1 : K) * a.2) = a
    rw [Grp.one_mul, Grp.one_mul]
  mul_one a := by
    show (a.1 * (1 : D), a.2 * (1 : K)) = a
    rw [Grp.mul_one, Grp.mul_one]
  inv_mul a := by
    show (a.1⁻¹ * a.1, a.2⁻¹ * a.2) = ((1 : D), (1 : K))
    rw [Grp.inv_mul, Grp.inv_mul]
  mul_inv a := by
    show (a.1 * a.1⁻¹, a.2 * a.2⁻¹) = ((1 : D), (1 : K))
    rw [Grp.mul_inv, Grp.mul_inv]

structure GrpHom (G : Type u) (H : Type v) [Grp G] [Grp H] where
  toFun : G → H
  map_mul : ∀ a b, toFun (a * b) = toFun a * toFun b

/-! ============================================================================
    §A.  Obstructions 2 and 3 of Part I

    A nontrivial centre destroys ICC; an infinite abelian quotient destroys
    property (T).  Either failure alone places a pair outside the hypotheses of
    Connes' conjecture.
    ========================================================================= -/

def IsCentral {G : Type u} [Grp G] (z : G) : Prop := ∀ g : G, g * z = z * g

def IsConj {G : Type u} [Grp G] (a b : G) : Prop := ∃ c : G, c * a = b * c

/-- The conjugacy class of a central element is the singleton containing it. -/
theorem conj_of_central {G : Type u} [Grp G] {z b : G}
    (hz : IsCentral z) (h : IsConj z b) : b = z := by
  obtain ⟨c, hc⟩ := h
  have h2 : b * c = z * c := by rw [← hc, hz c]
  exact Grp.mul_right_cancel h2

/-- The consequence of the ICC condition that Obstruction 2 refutes: every
non-identity element has *some* conjugate distinct from itself.

ICC — all non-identity conjugacy classes infinite — implies this, so refuting
it refutes ICC.  Stating the weaker property makes the refutation stronger and
avoids formalising cardinality, which is not the point at issue. -/
def NoSingletonClass (G : Type u) [Grp G] : Prop :=
  ∀ g : G, g ≠ 1 → ∃ b : G, IsConj g b ∧ b ≠ g

theorem not_noSingletonClass_of_central {G : Type u} [Grp G] {z : G}
    (hz : IsCentral z) (hz1 : z ≠ 1) : ¬ NoSingletonClass G := by
  intro h
  obtain ⟨b, hb, hbz⟩ := h z hz1
  exact hbz (conj_of_central hz hb)

/-- **Obstruction 2.**  In `D × K` with `D` abelian, the elements `(d, 1)` are
central; a nontrivial one has a singleton conjugacy class, so the group is not
ICC. -/
theorem prod_isCentral {D : Type u} {K : Type v} [CommGrp D] [Grp K] (d : D) :
    IsCentral ((d, (1 : K)) : D × K) := by
  intro p
  show (p.1 * d, p.2 * (1 : K)) = (d * p.1, (1 : K) * p.2)
  rw [CommGrp.mul_comm p.1 d, Grp.mul_one, Grp.one_mul]

theorem prod_not_ICC {D : Type u} {K : Type v} [CommGrp D] [Grp K]
    {d : D} (hd : d ≠ 1) : ¬ NoSingletonClass (D × K) := by
  refine not_noSingletonClass_of_central (prod_isCentral d) ?_
  intro h
  exact hd (congrArg Prod.fst h)

/-- Projection onto the abelian factor is a group homomorphism, and it is onto. -/
def fstHom (D : Type u) (K : Type v) [Grp D] [Grp K] : GrpHom (D × K) D where
  toFun p := p.1
  map_mul _ _ := rfl

theorem fstHom_surjective (D : Type u) (K : Type v) [Grp D] [Grp K] :
    Fn.Surjective (fstHom D K).toFun :=
  fun d => ⟨(d, 1), rfl⟩

def IsInfinite (A : Type u) : Prop := ∃ f : Nat → A, Fn.Injective f

/-- **Obstruction 3.**  `D × K` surjects as a group onto the abelian group `D`.
If `D` is infinite this exhibits an infinite abelian quotient.

The remaining step — property (T) forces a finite abelianisation, hence admits
no surjection onto an infinite abelian group — is Bekka–de la Harpe–Valette,
*Kazhdan's Property (T)*, Cor. 1.3.5.  It is cited, not formalised.
Axiomatising it here would add an unfalsifiable hypothesis rather than a
checkable one, which is the failure mode Part I is about. -/
theorem prod_has_infinite_abelian_quotient
    (D : Type u) (K : Type v) [CommGrp D] [Grp K] (hD : IsInfinite D) :
    ∃ f : GrpHom (D × K) D, Fn.Surjective f.toFun ∧ IsInfinite D :=
  ⟨fstHom D K, fstHom_surjective D K, hD⟩

/-! ### Scope of Part A

These obstructions apply to a group that is, or contains as a direct factor,
`D × K` with `D` abelian, nontrivial and infinite — the zero-carry /
trivial-action reading of the formalised construction.

They do **not** apply to `Z^4 ⋊ Sp_4(Z)` under the standard symplectic action.
There the fixed-point submodule is trivial, the centre is trivial, and the group
is ICC with property (T), as Section 10 of the paper states.  The `×` case and
the `⋊` case are different groups and are treated separately throughout. -/

/-! ============================================================================
    §B.  The deductive skeleton of Part II

    Two design decisions worth stating explicitly, since both were needed to
    make this appendix mean anything.

    (1) `IsICC` and `HasPropertyT` are opaque predicates, not classes carrying a
        `True` field.  A class with a `True` field is inhabited for every group
        in existence, which makes every hypothesis gated on it vacuous.

    (2) Bijectivity of the group morphism is asserted of the morphism that the
        classification *returns*, pinned by an equation hypothesis — not of an
        arbitrary homomorphism.  A blanket assertion over all homomorphisms is
        refutable, and an inconsistent axiom set proves every theorem stated
        after it, including the intended one.
    ========================================================================= -/

axiom VNAlg : Type

/-- The group von Neumann algebra `L(G)`. -/
axiom L : (G : Type u) → [Grp G] → VNAlg

/-- The Bernoulli crossed product `A_G = L^infty(X) ⋊ G`. -/
axiom Crossed : (G : Type u) → [Grp G] → VNAlg

axiom Tensor : VNAlg → VNAlg → VNAlg
axiom VNIso : VNAlg → VNAlg → Type
axiom VNHom : VNAlg → VNAlg → Type

/-- Opaque by design: nothing in this file can certify that a group is ICC, so
every theorem below is visibly conditional. -/
axiom IsICC : (G : Type u) → [Grp G] → Prop

/-- Opaque, for the same reason. -/
axiom HasPropertyT : (G : Type u) → [Grp G] → Prop

/-- The twisted comultiplication `Θ(f u_g) = f u_g ⊗ Φ(u_g)`.
Proposition 16 of the paper — unital, trace-preserving, injective — is the
content being asserted. -/
axiom twistedComult {G H : Type u} [Grp G] [Grp H] :
    VNIso (L G) (L H) → VNHom (Crossed G) (Tensor (Crossed G) (Crossed H))

/-- Ioana's trichotomy, JAMS 24 (2011), Theorem 8.2. -/
inductive Classification (G H : Type u) [Grp G] [Grp H] where
  /-- (NI1) fails: the image intertwines into a group-algebra leg. -/
  | degenerateI
  /-- (NI2) fails: the Cartan intertwines into the group algebra. -/
  | degenerateII
  /-- Case (III): `u Θ(u_g) u* = η(g) u_{δ₁ g} ⊗ v_{δ₂ g}`. -/
  | rigid (d₁ : GrpHom G G) (d₂ : GrpHom G H)

axiom classify {G H : Type u} [Grp G] [Grp H] :
    VNHom (Crossed G) (Tensor (Crossed G) (Crossed H)) → Classification G H

/-- Lemma 22, case (I): ruled out by weak convergence, using ICC. -/
axiom not_degenerateI {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) :
    classify (twistedComult Φ) ≠ Classification.degenerateI

/-- Lemma 22, case (II): ruled out because the Bernoulli Cartan does not embed
in the group algebra. -/
axiom not_degenerateII {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) :
    classify (twistedComult Φ) ≠ Classification.degenerateII

/-- Injectivity from factoriality: a nonzero star-homomorphism out of a II_1
factor is injective.  Note the shape — this concerns the `d₂` returned by
`classify`, identified by `h`, not an arbitrary homomorphism. -/
axiom rigid_d₂_injective {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) (d₁ : GrpHom G G) (d₂ : GrpHom G H)
    (h : classify (twistedComult Φ) = Classification.rigid d₁ d₂) :
    Fn.Injective d₂.toFun

/-- Surjectivity: finite index from countability of subfactor conjugacy classes
for property-(T) factors (Popa, ICM 2006, §4), then finite depth for amenable
property-(T) standard invariants (Popa, Doc. Math. 4 (1999), Cor. 1.2). -/
axiom rigid_d₂_surjective {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) (d₁ : GrpHom G G) (d₂ : GrpHom G H)
    (h : classify (twistedComult Φ) = Classification.rigid d₁ d₂) :
    Fn.Surjective d₂.toFun

/-- **Theorem 11.**  Modulo the axioms above, an isomorphism of the group von
Neumann algebras yields a group isomorphism. -/
theorem connes_rigidity {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) :
    ∃ f : GrpHom G H, Fn.Bijective f.toFun := by
  have hI := not_degenerateI hG hH tG tH Φ
  have hII := not_degenerateII hG hH tG tH Φ
  cases hcls : classify (twistedComult Φ) with
  | degenerateI => exact absurd hcls hI
  | degenerateII => exact absurd hcls hII
  | rigid d₁ d₂ =>
      exact ⟨d₂, rigid_d₂_injective hG hH tG tH Φ d₁ d₂ hcls,
                 rigid_d₂_surjective hG hH tG tH Φ d₁ d₂ hcls⟩

/-! ============================================================================
    §C.  Audit

    `#print axioms` reports exactly what each result depends on.  The three
    results of Part A depend on nothing; the theorem of Part B depends on the
    ten declared axioms and on nothing else.  Neither list contains `sorryAx`,
    so there are no unfinished proofs.
    ========================================================================= -/

#print axioms conj_of_central
#print axioms prod_not_ICC
#print axioms prod_has_infinite_abelian_quotient
#print axioms connes_rigidity
