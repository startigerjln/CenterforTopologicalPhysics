#!/usr/bin/env bash
# check.sh — fails loudly if the appendix ever regresses.
#
#   ./check.sh /path/to/lean ConnesAppendix.lean
#
# Exit 0 only if: the file compiles, contains no `sorry` outside comments, and
# no result depends on `sorryAx`.
#
# Wire this into the Makefile so a broken appendix cannot reach the PDF.

set -uo pipefail

LEAN="${1:-lean}"
FILE="${2:-ConnesAppendix.lean}"
fail=0

echo "== check.sh: $FILE =="

# --- 1. compiles at all -------------------------------------------------------
out=$("$LEAN" "$FILE" 2>&1); rc=$?
if [ $rc -ne 0 ]; then
  echo "FAIL  compilation failed (exit $rc)"
  echo "$out"
  exit 1
fi
echo "ok    compiles (exit 0)"

# --- 2. no `sorry` token outside comments ------------------------------------
# Strip block comments, then line comments, then look for the bare token.
stripped=$(perl -0777 -pe 's{/-.*?-/}{}gs' "$FILE" | sed 's/--.*$//')
if echo "$stripped" | grep -qw "sorry"; then
  echo "FAIL  'sorry' present in code"
  echo "$stripped" | grep -nw "sorry"
  fail=1
else
  echo "ok    no 'sorry' in code (occurrences in comments are ignored)"
fi

# --- 3. Lean's own sorry warning ---------------------------------------------
if echo "$out" | grep -qi "declaration uses 'sorry'"; then
  echo "FAIL  compiler reports a declaration using sorry"
  fail=1
else
  echo "ok    no 'declaration uses sorry' warning"
fi

# --- 4. kernel-level: sorryAx in no axiom list -------------------------------
# This is the real check. `sorry` anywhere in a dependency chain surfaces here,
# even if it came from an imported file.
if echo "$out" | grep -q "sorryAx"; then
  echo "FAIL  sorryAx appears in an axiom list"
  echo "$out" | grep -n "sorryAx"
  fail=1
else
  echo "ok    no sorryAx in any #print axioms output"
fi

# --- 5. other trust holes -----------------------------------------------------
if echo "$stripped" | grep -qE "\bnative_decide\b|\bunsafe\b|\badmit\b"; then
  echo "FAIL  native_decide / unsafe / admit present"
  fail=1
else
  echo "ok    no native_decide, unsafe or admit"
fi

# --- 6. report the declared axioms, for the record ---------------------------
echo
echo "-- declared axiom dependencies, verbatim from the compiler --"
echo "$out"

echo
if [ $fail -eq 0 ]; then
  echo "PASS"
else
  echo "FAILED"
fi
exit $fail
