# Connes' Rigidity Conjecture

**Disproof of the Counterexamples and Proof of the Theorem**

Jennifer Lorraine Nielsen \
Center for Topological Physics, Lawrence, Kansas \
University of Kansas

---

## Overview

Lean 4 formalization for the paper:

> **Connes' Rigidity Conjecture: Disproof of the Counterexamples and Proof of the Theorem**

The paper has two parts. Part I disproves three independent claimed counterexamples to Connes' rigidity conjecture (OpenAI, Anthropic, and Zhou). Part II proves the conjecture itself. The disproof and the proof are the same argument.

## The argument

The primary argument is a reductio ad absurdum. Assume the claimed algebra isomorphism L(Γ₀) ≅ L(Γτ). Equip both groups with Bernoulli actions (chosen by us, not inherited from either counterexample). The twisted comultiplication Θ(fuₘ) = fuₘ ⊗ Φ(uₘ) and Ioana's classification (Theorem 8.2, JAMS 2011) produce an injective group homomorphism δ₂ : Γ₀ → Γτ. The Borel density theorem forces δ₂ to preserve the fiber Z⁴. Margulis superrigidity forces an inner automorphism on the quotient Sp₄(Z). Schur's lemma forces a scalar map on the fiber. The resulting cohomological identity α\*[τ] = [τ] = 0 contradicts the non-vanishing of the Bockstein class. By reductio, L(Γ₀) ≇ L(Γτ). The only inputs are the group-theoretic structure of the groups and the published theorems of Ioana, Borel, Margulis, and Schur.

The reductio does not rely on any semantic mismatch between code labels and mathematical objects, on whether the ICC or property-(T) certificates in the Lean code are valid, or on any code-level observation whatsoever. It is purely mathematical.

The OpenAI formalization additionally exhibits three code-internal failures, each independently fatal: (i) a specification gap (cocycle extension verified as semidirect product), (ii) nontrivial centre destroying ICC, (iii) infinite abelian quotient destroying property (T). The Zhou construction falls to the same reductio: the unique maximal abelian normal subgroup must be preserved by any injective homomorphism, and Zhou's own non-isomorphism proof (Section 6) provides the contradiction.

Part II proves the conjecture: every countable discrete ICC group with Kazhdan's property (T) is W\*-superrigid. The proof is the same reductio applied universally. Assume L(G) ≅ L(H). The twisted comultiplication and Ioana's classification produce an injective δ₂ : G → H. Injectivity follows from factoriality. Finite index follows from countability of subfactor conjugacy classes for property-(T) factors. Surjectivity follows from the finite-depth theorem for amenable property-(T) standard invariants. Therefore G ≅ H. No shared subgroups, no semidirect-product structure, no special features beyond ICC and property (T) are required. The verification of the non-intertwining conditions is uniform in Φ because αₜ fixes Θ(uₘ) pointwise for every Φ (it acts on L∞(X), not on group unitaries) and Θ(L∞(X)) = L∞(X) ⊗ 1 independently of Φ. The argument is universal.

## The formalization

`ConnesAppendix.lean` compiles against a bare **Lean 4.22.0** toolchain with no Mathlib and no other package, with **zero errors and zero `sorry` placeholders**.

### Part A — Code-level obstructions (unconditional, no axioms)

Three theorems depending on no axioms whatsoever:

| Lean theorem | Content |
|---|---|
| `conj_of_central` | The conjugacy class of a central element is a singleton |
| `prod_not_ICC` | A product with a nontrivial abelian factor is not ICC |
| `prod_has_infinite_abelian_quotient` | The product surjects onto an infinite abelian group, destroying property (T) |

### Part B — Proof skeleton (conditional on cited axioms)

The deductive structure of Part II, with every analytic input declared as a named `axiom` corresponding to a cited theorem:

| Axiom | Source |
|---|---|
| `twistedComult` | Proposition 16 — unital, trace-preserving, injective |
| `classify` | Ioana, JAMS 2011, Theorem 8.2 |
| `not_degenerateI` | Lemma 22, case (I) — ruled out by weak convergence + ICC |
| `not_degenerateII` | Lemma 22, case (II) — Bernoulli Cartan does not embed in group algebra |
| `rigid_d₂_injective` | Factoriality of II₁ factors |
| `rigid_d₂_surjective` | Popa, ICM 2006 §4 + Doc. Math. 1999, Cor. 1.2 |

The main theorem:

```lean
theorem connes_rigidity {G H : Type u} [Grp G] [Grp H]
    (hG : IsICC G) (hH : IsICC H) (tG : HasPropertyT G) (tH : HasPropertyT H)
    (Φ : VNIso (L G) (L H)) :
    ∃ f : GrpHom G H, Fn.Bijective f.toFun
```

Two design choices prevent vacuity: `IsICC` and `HasPropertyT` are **opaque predicates** (not trivially satisfiable classes), and bijectivity is asserted of the specific morphism the classification **returns** (not of an arbitrary homomorphism).

### Axiom audit

The compiler's `#print axioms` confirms:

- Part A results depend on **no axioms**
- `connes_rigidity` depends on **exactly the ten declared axioms** and nothing else
- Neither list contains `sorryAx`

## Verification

### Quick check

```bash
cd lean
lean ConnesAppendix.lean
```

### Full guard (five levels)

```bash
cd lean
chmod +x check.sh
./check.sh lean ConnesAppendix.lean
```

The script checks: (1) compilation succeeds, (2) no `sorry` token outside comments, (3) no compiler sorry warning, (4) no `sorryAx` in any axiom list, (5) no `native_decide`, `unsafe`, or `admit`. The Makefile gates the LaTeX build on this check — a broken appendix cannot reach the document.

## Repository structure

```
├── lean/
│   ├── ConnesAppendix.lean     The formalization (paper appendix)
│   ├── check.sh                Five-level guard script
│   ├── Makefile                Lean check gates the LaTeX build
│   ├── lean-toolchain          Pins Lean 4.22.0
│   ├── lean-listings.tex       LaTeX listings config (110 Unicode rules)
│   └── appendix-demo.tex       Standalone LaTeX demo
└── .github/workflows/
    └── verify.yml              CI: runs check.sh on every push
```

## Contact

Jennifer Lorraine Nielsen \
JennyLorraineNielsen@gmail.com · JLNielsen@KU.edu \
Center for Topological Physics, Lawrence, Kansas

## License

MIT — see [LICENSE](LICENSE).
