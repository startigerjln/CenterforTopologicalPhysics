# TUFT — Lean 4 formalization (Part I forcing kernels + Part II scaffold)

## Verify the forcing kernels (no Mathlib needed, seconds)
    lean Tuft/ForcingCore.lean
Expected output: the five axiom-audit lines in STATUS.md, no errors.

## Build the Mathlib layer (local, ~10 min with cache)
    lake update
    lake exe cache get
    lake build
If the toolchain complains, copy Mathlib's `lean-toolchain` over this one.

See STATUS.md for the exact proved / cited / sorried ledger.
