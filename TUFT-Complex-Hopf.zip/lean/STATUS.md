# TUFT Lean formalization — status ledger

## Machine-checked NOW (Lean 4.32.2, zero sorries, this session)
Compiler output for Tuft/ForcingCore.lean (standalone, no Mathlib needed):

    'TUFT.charge_quantization_forces_holonomy' does not depend on any axioms
    'TUFT.product_has_zero_divisors' depends on axioms: [propext]
    'TUFT.classifying_unique' does not depend on any axioms
    'TUFT.U1_forcing' does not depend on any axioms
    'TUFT.every_field_configuration_is_in_the_bundle' does not depend on any axioms
    'TUFT.second_diff_affine_invariant' depends on axioms: [propext, Quot.sound]

| Lean name | Paper item |
|---|---|
| charge_quantization_forces_holonomy | thm:charge_quant_implies_holonomy |
| domain_idempotents_trivial, product_has_zero_divisors | algebraic heart of cor:self_entanglement (Z[c1] admits no splitting) |
| classifying_unique | thm:universality, Steps 1-3 |
| U1_forcing | thm:U1_forcing |
| every_field_configuration_is_in_the_bundle | the completeness clarification: each, every, and any field configuration is realized in the bundle |
| second_diff_affine_invariant | the c0/Lambda absorption convention of eq.(88): gauge cannot move second differences |

`propext` and `Quot.sound` are Lean's built-in axioms; nothing ad hoc was assumed.

## Enters as cited hypotheses (Mathlib has no classifying-space theory)
- Milnor (1956): CP-infinity with the Hopf bundle is a classifying object
  (the `hMilnor` hypothesis of U1_forcing).
- Steenrod/Husemoller: [X, BU(1)] classifies Prin_U(1)(X) for paracompact X
  (encoded as the `Classifies` structure).
- H*(CP^inf; Z) = Z[c1] and Kunneth (to apply the Kernel-2 algebra to bundles).
This is standard formalization practice when the library lacks the theory;
the logic DOWNSTREAM of these citations is fully machine-checked.

## Stated with sorry (Tuft/SpectralNumeric.lean, builds against Mathlib)
- [S1] sector_zeta_eq_hurwitz - routine series reindexing.
- [S2] zeta'(-2) = -zeta(3)/4pi^2 - true, cited, not yet in Mathlib.
- [S3] numeric mass-ratio bound - certified externally at 40 digits
  (tuft_verification.py); Lean interval arithmetic is the roadmap.

## Beyond current Lean/Mathlib entirely
Zeta-regularized determinants, Ray-Singer torsion, lens-space spectral
theory - the analytic engine of Part II. No formal library anywhere has
these today; they are the long-term formalization frontier.
