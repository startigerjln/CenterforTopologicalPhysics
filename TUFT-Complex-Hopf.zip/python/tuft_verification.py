#!/usr/bin/env python3
# =============================================================================
# TUFT NUMERICAL VERIFICATION SUITE
# Complex Hopf Fibration paper, August 5 2026 edition (v5)
#
# Recomputes every derived quantity in the paper from the printed formulas
# at 40-digit precision and compares against the paper's tables and PDG/CODATA.
#
# Requires: mpmath   (pip install mpmath)
# Sections 1-10: sectors that regenerate from the paper as printed.
# Section 11:    diagnostics for the two open items (boson Lambda_B; D(n)).
# =============================================================================

from mpmath import (mp, mpf, pi, sqrt, exp, log, sin, zeta, diff,
                    nsum, inf, quad)
from fractions import Fraction

mp.dps = 40
z3, z5 = zeta(3), zeta(5)

# ---- global inputs -----------------------------------------------------------
alpha = 1 / mpf('137.0360824')      # paper's derived alpha (Thm 56)
v     = mpf('246220')               # MeV; the single empirical input (Axiom 1)

# ---- reference values --------------------------------------------------------
CODATA_alpha_inv = mpf('137.035999178')
CODATA_G         = mpf('6.67430e-11')
PDG = {
    'me':  (mpf('0.51099895069'), mpf('1.6e-10')),
    'mmu': (mpf('105.6583755'),   mpf('0.0000023')),
    'mtau_2024': (mpf('1776.93'), mpf('0.09')),   # PDG 2024 average
    'mtau_old':  (mpf('1776.86'), mpf('0.12')),   # value printed in the paper
    'mW':  (mpf('80369.2'),  mpf('13.3')),
    'mZ':  (mpf('91188.0'),  mpf('2.0')),         # PDG 2024
    'mH':  (mpf('125200'),   mpf('110')),
    'mu_q': (mpf('2.16'),   mpf('0.07')),
    'md_q': (mpf('4.67'),   mpf('0.09')),
    'ms_q': (mpf('93.4'),   mpf('0.8')),
    'mc_q': (mpf('1270'),   mpf('20')),
    'mb_q': (mpf('4180'),   mpf('30')),
    'mt_q': (mpf('172760'), mpf('300')),
    'ae':  (mpf('1.15965218059e-3'), mpf('1.3e-13')),
    'amu': (mpf('1.165920715e-3'),  mpf('1.46e-10')),
    'dm21': (mpf('7.53e-5'),  mpf('0.18e-5')),
    'dm31': (mpf('2.453e-3'), mpf('0.033e-3')),
}

def hdr(t):
    print("\n" + "=" * 78); print(t); print("=" * 78)

def row(label, computed, ref=None, err=None, unit=""):
    s = f"  {label:<34} = {mp.nstr(computed, 10)} {unit}"
    if ref is not None:
        s += f"   [ref {mp.nstr(ref, 10)}"
        if err is not None and err != 0:
            s += f"  pull {mp.nstr((computed - ref)/err, 3)} sigma"
        else:
            s += f"  rel.dev {mp.nstr((computed - ref)/ref, 3)}"
        s += "]"
    print(s)

# =============================================================================
hdr("SECTION 1 - ANALYTIC ZETA IDENTITIES")
# =============================================================================
row("zeta'(0)",  zeta(0, 1, 1),  -log(2*pi)/2)
row("zeta'(-2)", zeta(-2, 1, 1), -z3/(4*pi**2))
row("zeta'(-4)", zeta(-4, 1, 1),  3*z5/(4*pi**4))
zp1 = zeta(-2, 1, 1) - zeta(0, 1, 1)
row("zeta'_1(0) = z'(-2)-z'(0)", zp1, mpf('0.888490076'))     # paper eq.(90)
row("sigma3*zeta(2) vs z3/24", (z3/(4*pi**2))*zeta(2), z3/24)  # Thm 66 identity

# =============================================================================
hdr("SECTION 2 - CHARGED LEPTONS  (eq. 88, S^3 shell)")
# =============================================================================
kappa  = exp(z3/(24*pi**2)) / (4*pi**2)
Lam3   = sqrt(2*pi) * v * kappa**6
a3     = 6*sqrt(2) * exp(z3/(24*pi**2))
sigma3 = z3/(4*pi**2)
D      = {1: mpf('1.203011392'), 2: mpf('4.806545406'), 3: mpf('10.818228646')}
tauK   = {1: mpf(1), 2: mpf(1), 3: sqrt(3)}
row("kappa", kappa); row("Lambda_Hopf (MeV)", Lam3)
row("a = 6*sqrt2*exp(z3/24pi^2)", a3, mpf('8.5284'))
mlep = {}
for n in (1, 2, 3):
    mlep[n] = Lam3*(n+1)*exp(a3*n - D[n] + n*alpha/6 + sigma3*log(tauK[n]))
row("m_e  (MeV)",  mlep[1], *PDG['me'])
row("m_mu (MeV)",  mlep[2], *PDG['mmu'])
row("m_tau (MeV)", mlep[3], *PDG['mtau_2024'])
print("  (paper's table used the older PDG tau:", PDG['mtau_old'][0], "+/-", PDG['mtau_old'][1], ")")
row("ratio m_mu/m_e", mlep[2]/mlep[1], PDG['mmu'][0]/PDG['me'][0])
row("ratio m_tau/m_e", mlep[3]/mlep[1], PDG['mtau_old'][0]/PDG['me'][0])
print("  NOTE: ratios exact to ~1e-9 by construction of D(n); absolute scale +3.41e-5.")

# =============================================================================
hdr("SECTION 3 - GAUGE BOSONS AND HIGGS  (eq. 97)")
# =============================================================================
r    = mpf(8)
LamB = v*sqrt(2/r)*sin(pi/r)*exp(-2*alpha)
aB   = -alpha*sqrt(2)/pi
zB   = sqrt(3)*alpha/(2*pi)
rf   = r + zB
TW = (sqrt(3)/2) * exp(aB + zB)
TZ = sin(4*pi/rf) / (4*sin(pi/rf))
TH = (mpf(2)/3) * exp(3*aB + 9*zB)
row("Lambda_B (MeV)", LamB, mpf('46429'))            # paper line 8065
mW = LamB*2*exp(alpha/6)*TW
mZ = LamB*3*exp(2*alpha/6)*TZ
mH = LamB*4*exp(3*alpha/6)*TH
row("m_W (MeV)", mW, *PDG['mW'])
row("m_Z (MeV)", mZ, *PDG['mZ'])
row("m_H (MeV)", mH, *PDG['mH'])
print("  Paper table prints: 80369.5 / 91187.8 / 125225  (see Section 11 diagnostic).")

# =============================================================================
hdr("SECTION 4 - QUARKS  (eq. 122, S^5 shell)")
# =============================================================================
spec5 = (3*z5 + 5*pi**2*z3) / (8*pi**4)
kap5  = exp(spec5/6) / (8*pi**3)
Lam5  = (2*pi/sqrt(3)) * v * kap5**3
a5    = exp(spec5/6) * sqrt(3) * (2 + z3/(4*pi**2))
C5, b5, s5 = z3/12, z5/(8*pi**4), z3/(16*pi**2)
lT = {1: 2/(3*sqrt(3)), 2: 2/pi + z3/(24*pi), 3: 2/pi - z3/(24*pi)}
tq = {1: mpf(1), 2: mpf(4), 3: mpf(3)}
pref = {1: mpf(2)/3, 2: mpf(1), 3: mpf(1)}
row("Lambda_5 (MeV)", Lam5, mpf('6.09144e-2'))
row("a_5", a5, mpf('3.564112'))
names = {1: ('u', 'd'), 2: ('s', 'c'), 3: ('b', 't')}
pdgq  = {1: ('mu_q', 'md_q'), 2: ('ms_q', 'mc_q'), 3: ('mb_q', 'mt_q')}
mq = {}
for n in (1, 2, 3):
    base = a5*n + C5*n**2 + b5*n*(n+1)/2 + s5*log(tq[n])
    m_minus = Lam5*(n+1)*exp(base - lT[n]*n)*pref[n]
    m_plus  = Lam5*(n+1)*exp(base + lT[n]*n)*pref[n]
    mq[names[n][0]], mq[names[n][1]] = m_minus, m_plus
    row(f"m_{names[n][0]} (MeV)", m_minus, *PDG[pdgq[n][0]])
    row(f"m_{names[n][1]} (MeV)", m_plus,  *PDG[pdgq[n][1]])

# =============================================================================
hdr("SECTION 5 - NEUTRINOS  (eq. 146, S^9 shell)")
# =============================================================================
kap9 = exp(mpf('-0.41364')/16) / (32*pi**5)   # zeta'_{Delta2}(0) as quoted, eq.(137)
Lam9 = sqrt(2*pi) * v * kap9**4
a9   = sqrt(5)
C9   = -(z3/8)*(1 + z3/28)
b9, s9 = z5/(8*pi**4), z3/(8*pi**2)
row("Lambda_9 (MeV)", Lam9, mpf('6.052e-11'))
row("C_9", C9, mpf('-0.15671'))
mnu = []
for n in (1, 2, 3):
    m = Lam9*(n+1)*exp(a9*n + C9*n**2 + b9*n*(n+1)/2 + s9*log(tq[n]))
    mnu.append(m*mpf('1e6'))   # eV
    row(f"m_nu{n} (eV)", mnu[-1])
row("dm2_21 (eV^2)", mnu[1]**2 - mnu[0]**2, *PDG['dm21'])
row("dm2_31 (eV^2)", mnu[2]**2 - mnu[0]**2, *PDG['dm31'])

# =============================================================================
hdr("SECTION 6 - FINE-STRUCTURE CONSTANT  (Thm 56)")
# =============================================================================
aW = (9/(8*pi**4)) * (pi**5/1920)**(mpf(1)/4)
row("1/alpha (geometric)", 1/aW, mpf('137.0360824'))
row("  vs CODATA", 1/aW, CODATA_alpha_inv, mpf('2.1e-8'))

# =============================================================================
hdr("SECTION 7 - NEWTON'S CONSTANT AND PLANCK LENGTH  (eq. 175)")
# =============================================================================
hbar, c = mpf('1.054571817e-34'), mpf('2.99792458e8')
MeV_kg  = mpf('1.78266192e-30')
Meff = v / sqrt((2*pi + alpha)*alpha**16)          # MeV
G    = (hbar*c) / (Meff*MeV_kg)**2
row("G (m^3 kg^-1 s^-2)", G, CODATA_G)
row("  vs paper's quote", G, mpf('6.6748e-11'))
row("Planck length (m)", sqrt(hbar*G/c**3), mpf('1.6163e-35'))

# =============================================================================
hdr("SECTION 8 - COSMOLOGICAL CONSTANT  (Thm 66)")
# =============================================================================
S_cs = 2 + z3/24
row("CS exponent 2 + z3/24", S_cs, mpf('2.05009'))
row("Lambda (Planck units)", 3*exp(-S_cs/aW), mpf('2.94e-122'))
print("  Observed: ~2.85e-122 (paper: 1.7 sigma high, parameter-free).")

# =============================================================================
hdr("SECTION 9 - ANOMALOUS MAGNETIC MOMENTS  (eqs. 153-158)")
# =============================================================================
# As printed: 1/(2pi) multiplies Delta-phi_univ ONLY; the L-terms add directly.
dphi_univ = alpha*exp(-alpha*z3*13/(24*pi) - alpha**2*z5/(4*pi**2)
                      - alpha**3*mpf('1.748452')/56 - alpha**4*mpf('0.41364')/16)
def a_lepton(m):
    L  = log(m/PDG['me'][0])
    d4 = (alpha/(2*pi))**2*(pi/12)*(1 - alpha*z3/(24*pi))*L*(L-2)
    d5 = (alpha/(2*pi))**3*(-(mpf('0.5') - 4*sigma3))*L
    d6 = -(alpha/(2*pi))**4*(1 - sigma3)*L**2*(L-2)
    return dphi_univ/(2*pi) + d4 + d5 + d6
row("a_e",   a_lepton(PDG['me'][0]),  *PDG['ae'])
row("a_mu",  a_lepton(PDG['mmu'][0]), *PDG['amu'])
row("a_tau", a_lepton(PDG['mtau_old'][0]), mpf('1.177365e-3'))
print("  (a_tau is a true prediction; no measurement exists at this precision.)")

# =============================================================================
hdr("SECTION 10 - CKM AND WEINBERG ANGLE")
# =============================================================================
row("|V_us| = sqrt(md/ms)", sqrt(mq['d']/mq['s']), mpf('0.2245'), mpf('0.0008'))
row("|V_cb|", (mpf(2)/3)*abs(sqrt(mq['s']/mq['b']) - sqrt(mq['c']/mq['t'])),
    mpf('0.0421'), mpf('0.0008'))
row("sin^2(thetaW) = 3/(4pi)", 3/(4*pi), mpf('0.23873'))
row("on-shell 1-(mW/mZ)^2", 1 - (mpf('80369.5')/mpf('91187.8'))**2, mpf('0.22320'))

# =============================================================================
hdr("SECTION 11 - DIAGNOSTICS (the two open items)")
# =============================================================================
print("\n[11a] Boson scale: uniform offset between eq.(97) and the paper's table")
for name, m, tab in (('W', mW, mpf('80369.5')), ('Z', mZ, mpf('91187.8')),
                     ('H', mH, mpf('125225'))):
    print(f"  {name}: formula {mp.nstr(m,7)}  table {mp.nstr(tab,7)}"
          f"  table/formula = {mp.nstr(tab/m, 8)}")
print(f"  Effective Lambda_B implied by the table: {mp.nstr(LamB*mpf('80369.5')/mW, 7)}"
      f"  (printed Lambda_B = {mp.nstr(LamB, 7)})")
print("  -> one common factor exp(-5.51e-4) ~ exp(-0.0755*alpha) missing from eq.(97).")

print("\n[11b] D(n) provenance: second-difference (affine-invariant) tests")
d2D = D[1] - 2*D[2] + D[3]
print(f"  Delta^2 of boxed D values: {mp.nstr(d2D, 10)}   <- target fingerprint")
# route 1: paper eq.(89)/(91) - the sector (Beltrami, first-power) zeta
zpn = [diff(lambda s, n=n: zeta(s-2, n+1) - zeta(s, n+1), 0) for n in (1, 2, 3)]
print(f"  eq.(89) zeta'_n(0): {[mp.nstr(x,10) for x in zpn]}  "
      f"Delta^2 = {mp.nstr(zpn[0]-2*zpn[1]+zpn[2], 8)}")
# route 2: Nash-O'Connor twisted one-form lens determinants (their eqs. 1.1, 7.4)
NO_S3 = -4*(zeta(-2,1,1) - zeta(0,1,1))
NO_L2 = -3*z3/pi**2 - 2*log(2)
I3 = quad(lambda t: log(2*sin(t)), [0, pi/3])
NO_L3 = z3/(3*pi**2) - 2*log(2*sin(pi/3)) + (2/pi)*I3
no = (NO_S3, NO_L2, NO_L3)
print(f"  N-O twisted lnDet d*d1: {[mp.nstr(x,9) for x in no]}  "
      f"Delta^2 = {mp.nstr(no[0]-2*no[1]+no[2], 8)}")
# route 3: untwisted Z_n-equivariant (weights k=2m == 0 mod n within each level)
def Ncount(L, n):
    return sum(1 for k in range(-L, L+1, 2) if k % n == 0)
def Gam(l, n):
    return (l+2)*Ncount(l-1, n) + l*Ncount(l+1, n)
def lnDet_untw(n):
    P = 2*n
    def det3(m):
        return (m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
              - m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
              + m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]))
    classes = []
    for rres in range(P):
        ls = [l for l in range(1, 8*P) if l % P == rres][:5]
        l1, l2, l3 = ls[:3]
        M = [[Fraction(x*x), Fraction(x), Fraction(1)] for x in (l1, l2, l3)]
        Y = [Fraction(Gam(x, n)) for x in (l1, l2, l3)]
        D0 = det3(M)
        aa = det3([[Y[i], M[i][1], M[i][2]] for i in range(3)]) / D0
        bb = det3([[M[i][0], Y[i], M[i][2]] for i in range(3)]) / D0
        cc = det3([[M[i][0], M[i][1], Y[i]] for i in range(3)]) / D0
        for lv in ls[3:]:
            assert aa*lv*lv + bb*lv + cc == Gam(lv, n)
        classes.append((aa, bb, cc, ls[0]))
    def zf(s):
        tot = mpf(0)
        for aa, bb, cc, l0 in classes:
            A = mpf(str(aa)); B = mpf(str(bb - 2*aa)); C = mpf(str(aa - bb + cc))
            t = mpf(l0 + 1) / P
            tot += (A*P**(2-2*s)*zeta(2*s-2, t) + B*P**(1-2*s)*zeta(2*s-1, t)
                    + C*P**(-2*s)*zeta(2*s, t))
        return tot
    direct = sum(Gam(l, n)/mpf(l+1)**6 for l in range(1, 5000))
    assert abs(zf(mpf(3)) - direct)/direct < mpf('1e-8')   # convergent-region check
    return -diff(zf, 0)
un = (NO_S3, lnDet_untw(2), lnDet_untw(3))
print(f"  untwisted equivariant   : {[mp.nstr(x,9) for x in un]}  "
      f"Delta^2 = {mp.nstr(un[0]-2*un[1]+un[2], 8)}")
print("  Convention multipliers {1/4,1/2,1,2,4} (zeta_D1(s)=2*zeta_B(2s)) applied to")
print("  each route's |Delta^2| never reach 2.408149226. The boxed D(n) are the output")
print("  of none of these; the worksheet that produced them remains to be displayed.")

# =============================================================================
hdr("SUMMARY")
# =============================================================================
print("""  Regenerate exactly from the paper as printed:
    zeta identities | lepton mass ratios | all six quark masses | all three
    neutrino masses + both splittings | alpha | G | Lambda | CKM | Weinberg
    angle | complete g-2 sector (a_e at 1e-9 from experiment).
  Open items (Section 11):
    [11a] boson table needs the Lambda_B correction factor printed in eq.(97);
    [11b] boxed D(n) values need their generating computation displayed.""")
